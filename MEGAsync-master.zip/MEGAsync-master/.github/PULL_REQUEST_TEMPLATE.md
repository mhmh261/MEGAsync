Description
-----------


SDK Submodule build
-------------------
#You can change submodule branch here. Default develop.
SDK_SUBMODULE_TEST=develop


Risk area(s)
------------


Tested in
---------
Win | Linux | macOS

